import React, { useState, useEffect, useRef } from 'react';
import { motion, useSpring, useTransform, useMotionValue } from 'motion/react';
import { useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, RoundedBox, Icosahedron } from '@react-three/drei';
import { WHATSAPP_URL, EMAIL_URL } from '../lib/constants';
import { ExternalLink, Mail, MessageCircle } from 'lucide-react';

export const TiltCard = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x, { stiffness: 150, damping: 20 });
  const mouseYSpring = useSpring(y, { stiffness: 150, damping: 20 });

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    x.set(mouseX / width - 0.5);
    y.set(mouseY / height - 0.5);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className={`perspective-1000 relative ${className}`}
    >
      <div 
        style={{ transform: "translateZ(40px)" }} 
        className="w-full h-full bg-white rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-zinc-100 p-8 hover:shadow-[0_40px_80px_rgba(0,0,0,0.08)] transition-shadow duration-500 will-change-transform"
      >
        {children}
      </div>
    </motion.div>
  );
};

export const TypingEffect = () => {
  const [text, setText] = useState("");
  const fullText = "Error 404: Bad Website Not Found.";
  const newText = "Status 200: Perfect Website Found.";
  const [phase, setPhase] = useState("typing1"); // typing1, deleting, typing2

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    if (phase === "typing1") {
      if (text.length < fullText.length) {
        timeout = setTimeout(() => {
          setText(fullText.slice(0, text.length + 1));
        }, 100);
      } else {
        timeout = setTimeout(() => setPhase("deleting"), 2000);
      }
    } else if (phase === "deleting") {
      if (text.length > 0) {
        timeout = setTimeout(() => {
          setText(text.slice(0, -1));
        }, 50);
      } else {
        setPhase("typing2");
      }
    } else if (phase === "typing2") {
      if (text.length < newText.length) {
        timeout = setTimeout(() => {
          setText(newText.slice(0, text.length + 1));
        }, 80);
      }
    }
    
    return () => clearTimeout(timeout);
  }, [text, phase]);

  return (
    <div className="font-mono text-2xl md:text-3xl font-bold text-zinc-400 h-10 mb-6 flex items-center justify-center md:justify-start">
      <span>{text}</span>
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ repeat: Infinity, duration: 0.8 }}
        className="inline-block w-3 h-8 bg-black ml-1"
      />
    </div>
  );
};

export const HeroShapes = () => {
  const groupRef = useRef<any>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
      groupRef.current.rotation.x = Math.cos(state.clock.elapsedTime * 0.2) * 0.1;
    }
  });

  return (
    <group ref={groupRef}>
      <Float speed={2} rotationIntensity={1.5} floatIntensity={2}>
        <Icosahedron args={[1.5, 0]} position={[-2, 1, -2]}>
          <MeshDistortMaterial color="#f4f4f5" wireframe distort={0.3} speed={2} />
        </Icosahedron>
      </Float>
      
      <Float speed={1.5} rotationIntensity={2} floatIntensity={1.5}>
        <RoundedBox args={[2, 2, 2]} radius={0.2} smoothness={4} position={[1.5, -1, 1]} rotation={[Math.PI / 4, Math.PI / 4, 0]}>
          <meshStandardMaterial color="#ffffff" roughness={0.1} metalness={0.8} />
        </RoundedBox>
      </Float>

      <Float speed={2.5} rotationIntensity={1} floatIntensity={2.5}>
        <mesh position={[2, 2, -1]}>
          <torusGeometry args={[0.8, 0.2, 16, 32]} />
          <meshStandardMaterial color="#25D366" roughness={0.3} metalness={0.5} />
        </mesh>
      </Float>
      
       <Float speed={1} rotationIntensity={0.5} floatIntensity={1}>
        <mesh position={[-1.5, -1.5, 2]}>
           <octahedronGeometry args={[1]} />
           <meshStandardMaterial color="#18181b" roughness={0.2} metalness={0.6} wireframe/>
        </mesh>
      </Float>
    </group>
  );
};

export const CTASection = () => (
  <section className="py-32 px-6 bg-white border-t border-zinc-100 overflow-hidden relative">
    {/* Subtle Grid Background */}
    <div className="absolute inset-0 z-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
    
    <div className="max-w-4xl mx-auto text-center relative z-10">
      <h2 className="text-5xl md:text-7xl font-bold tracking-tight mb-8">Ready to upgrade your web presence?</h2>
        <p className="text-xl text-zinc-500 mb-12">Stop losing customers to a bad website. Send us a message right now.</p>
        
        <div className="flex flex-col sm:flex-row gap-6 justify-center">
          <a 
            href={WHATSAPP_URL} 
            target="_blank" 
            rel="noreferrer"
            className="flex items-center justify-center gap-3 bg-[#25D366] text-white px-10 py-5 rounded-full font-bold text-lg shadow-[0_20px_40px_rgba(37,211,102,0.3)] hover:-translate-y-1 transition-all"
          >
            <MessageCircle size={24} />
            WhatsApp Us Now
          </a>
          <a 
            href={EMAIL_URL}
            className="flex items-center justify-center gap-3 bg-black text-white px-10 py-5 rounded-full font-bold text-lg hover:-translate-y-1 hover:shadow-xl transition-all"
          >
            <Mail size={24} />
            connor@web404.co.za
          </a>
        </div>
        <p className="mt-8 font-mono text-zinc-400">Or call us: <a href="tel:+27697321153" className="hover:text-black">069 732 1153</a></p>
    </div>
  </section>
);
