import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Code2, Menu, X, MessageCircle } from 'lucide-react';
import { WHATSAPP_URL, EMAIL_URL } from '../lib/constants';

export default function Layout() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Services", href: "/services" },
    { name: "Portfolio", href: "/portfolio" },
    { name: "Pricing", href: "/pricing" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAFA] font-sans selection:bg-zinc-200 flex flex-col">
      {/* Navigation */}
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-white/80 backdrop-blur-lg shadow-sm py-4" : "bg-transparent py-6"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center text-white transform group-hover:scale-105 transition-transform">
              <Code2 size={24} />
            </div>
            <span className="font-mono font-bold text-2xl tracking-tight text-black">Web404</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6 font-medium text-sm text-zinc-600">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.href} 
                className={`transition-colors hover:text-black ${location.pathname === link.href ? 'text-black font-semibold' : ''}`}
              >
                {link.name}
              </Link>
            ))}
            <a 
              href={WHATSAPP_URL} target="_blank" rel="noreferrer"
              className="bg-black text-white px-5 py-2.5 rounded-full hover:shadow-lg hover:shadow-zinc-300 transition-all active:scale-95 ml-2"
            >
              Get a Quote
            </a>
          </div>

          {/* Mobile Nav Toggle */}
          <button className="md:hidden p-2 text-zinc-800" onClick={() => setMobileMenuOpen(true)}>
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-50 bg-white/95 backdrop-blur-xl flex flex-col items-center justify-center gap-8 md:hidden"
          >
            <button className="absolute top-6 right-6 p-2 text-zinc-800" onClick={() => setMobileMenuOpen(false)}>
              <X size={28} />
            </button>
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.href} 
                className="text-2xl font-bold hover:text-zinc-500"
              >
                {link.name}
              </Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-[#FAFAFA] border-t border-zinc-200 py-12 px-6 text-center md:text-left">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8 items-center border-b border-zinc-200 pb-12 mb-8">
           <div>
             <div className="flex items-center justify-center md:justify-start gap-2 mb-4">
               <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white">
                 <Code2 size={18} />
               </div>
               <span className="font-mono font-bold text-xl">Web404</span>
             </div>
             <p className="text-zinc-500 max-w-xs mx-auto md:mx-0">Premium web development in South Africa. We fix broken web presence.</p>
           </div>
           <div className="flex flex-col md:items-end justify-center gap-3">
              <a href={WHATSAPP_URL} className="text-zinc-600 hover:text-black font-semibold flex items-center gap-2 justify-center">WhatsApp: 069 732 1153</a>
              <a href={EMAIL_URL} className="text-zinc-600 hover:text-black font-semibold flex items-center gap-2 justify-center">connor@web404.co.za</a>
           </div>
        </div>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-sm text-zinc-500">
          <p>&copy; {new Date().getFullYear()} Web404. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <Link to="/" className="hover:text-black">Privacy Policy</Link>
            <Link to="/" className="hover:text-black">Terms of Service</Link>
          </div>
        </div>
      </footer>

      {/* Floating Mobile WhatsApp */}
      <a 
        href={WHATSAPP_URL} 
        target="_blank" 
        rel="noreferrer"
        className="md:hidden fixed bottom-6 right-6 bg-[#25D366] text-white p-4 rounded-full shadow-[0_10px_30px_rgba(37,211,102,0.4)] z-[60] flex items-center justify-center animate-bounce"
        aria-label="Contact us on WhatsApp"
      >
        <MessageCircle size={32} />
      </a>
    </div>
  );
}
