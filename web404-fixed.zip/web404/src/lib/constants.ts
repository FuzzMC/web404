export const WHATSAPP_URL = "https://wa.me/27697321153";
export const EMAIL_URL = "mailto:connor@web404.co.za";
