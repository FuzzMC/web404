import React from 'react';
import { ExternalLink, ArrowRight } from 'lucide-react';
import { CTASection } from '../components/SharedUI';
import { WHATSAPP_URL } from '../lib/constants';

export default function Portfolio() {
  return (
    <>
      <section className="pt-32 pb-24 px-6 bg-[#FAFAFA]">
         <div className="max-w-7xl mx-auto mt-16">
           <div className="text-center mb-16 max-w-2xl mx-auto">
             <h1 className="text-5xl font-bold tracking-tight mb-6">Our Recent Work</h1>
             <p className="text-xl text-zinc-500">A glimpse into what we've been building for South African businesses. We design for conversion and code for speed.</p>
           </div>
           
           <div className="grid md:grid-cols-2 gap-12">
             {[
               { title: "Kalahari Outdoors", tags: ["eCommerce", "Shopify"], image: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=2021&auto=format&fit=crop", desc: "A modern, high-converting online store for a premium outdoor gear brand based in Cape Town." },
               { title: "Nexus Tech Solutions", tags: ["B2B Tech", "React"], image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop", desc: "A sleek, dark-mode focused landing page for a B2B cybersecurity firm." },
               { title: "Artisan Coffee Roasters", tags: ["Local Business", "SEO"], image: "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=2014&auto=format&fit=crop", desc: "A charming, mobile-optimized site that increased in-store foot traffic by 40% through local SEO." },
               { title: "Velocity Fitness", tags: ["Web App", "Custom UI"], image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop", desc: "A custom membership dashboard and booking system for a high-end gym franchise." }
             ].map((project, i) => (
               <div key={i} className="group cursor-pointer">
                  <div className="relative h-[350px] md:h-[450px] rounded-3xl overflow-hidden mb-6 bg-zinc-100 shadow-sm border border-zinc-100">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-300"></div>
                    <div className="absolute top-6 left-6 flex gap-2">
                      {project.tags.map(tag => (
                        <span key={tag} className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-black uppercase tracking-wider">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="bg-white text-black w-16 h-16 rounded-full flex items-center justify-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                         <ExternalLink size={24} />
                      </div>
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold mb-3 group-hover:text-zinc-600 transition-colors">{project.title}</h3>
                  <p className="text-zinc-500 leading-relaxed max-w-lg text-lg">{project.desc}</p>
               </div>
             ))}
           </div>
           
           <div className="mt-20 text-center">
             <a 
               href={WHATSAPP_URL} 
               target="_blank" 
               rel="noreferrer"
               className="inline-flex items-center gap-2 font-bold text-lg hover:text-zinc-500 transition-colors group"
             >
               Ready to add your project to this list? Message us <ArrowRight className="group-hover:translate-x-1 transition-transform" />
             </a>
           </div>
         </div>
      </section>

      <CTASection />
    </>
  );
}
