import React from 'react';
import { CTASection } from '../components/SharedUI';

export default function Contact() {
  return (
    <>
      <div className="pt-32 bg-[#FAFAFA]">
        <div className="max-w-3xl mx-auto text-center px-6 mt-16 mb-8">
            <h1 className="text-5xl font-bold tracking-tight mb-6">Contact Us</h1>
            <p className="text-xl text-zinc-500">We're always available to talk about architecture, design, and scaling your business.</p>
        </div>
      </div>
      <CTASection />
    </>
  );
}
