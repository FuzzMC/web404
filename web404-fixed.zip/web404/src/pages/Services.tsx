import React from 'react';
import { Rocket, Monitor, LineChart, ArrowRight, Smartphone, ShieldCheck } from 'lucide-react';
import { TiltCard, CTASection } from '../components/SharedUI';

export default function Services() {
  return (
    <>
      <section className="pt-32 pb-24 px-6 bg-white relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h1 className="text-5xl font-bold tracking-tight mb-6 mt-16">Our Services</h1>
            <p className="text-xl text-zinc-500">Everything you need to launch and scale your business online, backed by custom, high-end code.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Website Design", desc: "Sleek, modern, and highly responsive sites tailored to your brand.", icon: <Monitor className="w-8 h-8 text-black" /> },
              { title: "eCommerce Stores", desc: "Sell 24/7 with secure, easy-to-manage online shops.", icon: <Rocket className="w-8 h-8 text-black" /> },
              { title: "SEO Optimization", desc: "Rank higher on Google and dominate your local market.", icon: <LineChart className="w-8 h-8 text-black" /> },
              { title: "Landing Pages", desc: "High-converting single pages built for your ad campaigns.", icon: <ArrowRight className="w-8 h-8 text-black" /> },
              { title: "Mobile UI/UX", desc: "Mobile-first designs ensuring perfect experiences on any device.", icon: <Smartphone className="w-8 h-8 text-black" /> },
              { title: "Maintenance & Support", desc: "We manage the technical side so you can run your business.", icon: <ShieldCheck className="w-8 h-8 text-black" /> }
            ].map((service, i) => (
              <div key={i}>
                <TiltCard className="h-[280px]">
                  <div className="mb-6 w-14 h-14 bg-zinc-100 rounded-xl flex items-center justify-center">
                    {service.icon}
                  </div>
                  <h4 className="text-2xl font-bold mb-3">{service.title}</h4>
                  <p className="text-zinc-500 leading-relaxed">{service.desc}</p>
                </TiltCard>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
