import React, { useState } from 'react';
import { CheckCircle2, ArrowRight, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TiltCard, CTASection } from '../components/SharedUI';
import { WHATSAPP_URL } from '../lib/constants';

export default function Pricing() {
  return (
    <>
      <section className="pt-32 pb-24 px-6 bg-[#FAFAFA]">
        <div className="max-w-7xl mx-auto mt-16 text-center">
          <h1 className="text-5xl font-bold tracking-tight mb-6">Professional websites don't have to break the bank.</h1>
          <p className="text-xl text-zinc-500 mb-16 max-w-2xl mx-auto">
            Transparent pricing with no hidden fees. We build for performance, conversion, and zero headaches.
          </p>

          <div className="grid md:grid-cols-3 gap-8 mb-16 text-left">
            {/* Landing Page Package */}
            <div className="bg-white border border-zinc-200 rounded-3xl p-8 hover:shadow-xl transition-shadow duration-300 flex flex-col relative">
              <h3 className="text-2xl font-bold mb-2">Landing Page</h3>
              <p className="text-zinc-500 mb-6 h-12">Perfect for marketing campaigns, single products, or pre-launch.</p>
              <div className="mb-8">
                <span className="text-4xl font-bold">R1,500</span>
                <span className="text-zinc-500 ml-2">/ starting</span>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                {["Single Page Layout", "Contact & Lead Capture Forms", "Basic On-Page SEO", "Free Demo Website", "Delivery < 1 Week", "Mobile-First Design"].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-zinc-400 shrink-0 mt-0.5" />
                    <span className="text-zinc-700">{item}</span>
                  </li>
                ))}
              </ul>
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="block w-full py-4 px-6 bg-zinc-100 hover:bg-zinc-200 text-center font-bold text-zinc-900 rounded-full transition-colors">
                Get Started
              </a>
            </div>

            {/* Business Package (Highlighted) */}
            <div className="bg-black text-white border border-black rounded-3xl p-8 py-10 shadow-2xl relative transform md:-translate-y-4 flex flex-col z-10">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#25D366] text-black font-bold text-xs uppercase tracking-widest py-1 px-4 rounded-full">
                Most Popular
              </div>
              <h3 className="text-2xl font-bold mb-2">Business</h3>
              <p className="text-zinc-400 mb-6 h-12">For local service businesses wanting to dominate their market.</p>
              <div className="mb-8">
                <span className="text-4xl font-bold">R3,500</span>
                <span className="text-zinc-400 ml-2">/ starting</span>
              </div>
              <ul className="space-y-4 mb-8 flex-1 border-t border-zinc-800 pt-8">
                {["Up to 5 Custom Pages", "Advanced Local SEO Setup", "Google My Business Linking", "Free Demo Website", "Delivery < 2 Weeks", "SSL & Domain Setup"].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-[#25D366] shrink-0 mt-0.5" />
                    <span className="text-zinc-300">{item}</span>
                  </li>
                ))}
              </ul>
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="block w-full py-4 px-6 bg-white hover:bg-zinc-100 text-center font-bold text-black rounded-full transition-colors">
                Get Started
              </a>
            </div>

            {/* eCommerce Package */}
            <div className="bg-white border border-zinc-200 rounded-3xl p-8 hover:shadow-xl transition-shadow duration-300 flex flex-col relative">
              <h3 className="text-2xl font-bold mb-2">eCommerce</h3>
              <p className="text-zinc-500 mb-6 h-12">Sell your products 24/7 with a fully configured online store.</p>
              <div className="mb-8">
                <span className="text-4xl font-bold">R6,500</span>
                <span className="text-zinc-500 ml-2">/ starting</span>
              </div>
              <ul className="space-y-4 mb-8 flex-1">
                {["Fully Functional Online Store", "Secure Payment Gateways", "First 20 Products Uploaded", "Free Demo Website", "Delivery 3-4 Weeks", "Store Management Training"].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-zinc-400 shrink-0 mt-0.5" />
                    <span className="text-zinc-700">{item}</span>
                  </li>
                ))}
              </ul>
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="block w-full py-4 px-6 bg-zinc-100 hover:bg-zinc-200 text-center font-bold text-zinc-900 rounded-full transition-colors">
                Get Started
              </a>
            </div>
          </div>

          <p className="text-sm font-bold text-red-500 uppercase tracking-widest mt-8">Limited spots available this month</p>
        </div>
      </section>

      <section className="py-24 px-6 bg-white border-t border-zinc-100">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold tracking-tight text-center mb-16">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            {[
              { q: "How long does it take to build a website?", a: "Our usual turnaround time is under 2 weeks. We move quickly so your site is up and running without endless agency delays." },
              { q: "Do I need to pay monthly maintenance fees?", a: "You're not forced into it! We offer handover training if you want to manage it yourself, but most clients prefer our affordable maintenance plans to keep their site secure and updated." },
              { q: "Will my website show up on Google?", a: "Yes. All our sites are built with technical SEO best practices (fast load times, correct headings, semantic HTML). For ongoing keyword dominance, we offer dedicated SEO retainers." },
              { q: "Can we manage the site/store ourselves after launch?", a: "Absolutely. We build on user-friendly CMS platforms (like Shopify or WordPress/React hybrid headless) and provide handover documentation." },
            ].map((faq, i) => {
              const [isOpen, setIsOpen] = useState(false);
              return (
                <div key={i} className="bg-white border border-zinc-200 rounded-2xl overflow-hidden shadow-sm">
                  <button 
                    onClick={() => setIsOpen(!isOpen)}
                    className="w-full px-6 py-5 text-left flex justify-between items-center bg-white font-bold text-lg hover:bg-zinc-50 transition-colors"
                  >
                    {faq.q}
                    <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
                      <ChevronDown className="text-zinc-400" />
                    </motion.div>
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-6 pb-6 text-zinc-600 border-t border-zinc-100 pt-4">
                          {faq.a}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
