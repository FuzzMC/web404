import React, { Suspense } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Mail, MessageCircle, CheckCircle2, Zap, Globe2, CodeIcon, Star, UserCircle2 } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { Environment, PerspectiveCamera, Icosahedron, Float, MeshDistortMaterial } from '@react-three/drei';
import { Link } from 'react-router-dom';
import { TypingEffect, TiltCard, HeroShapes, CTASection } from '../components/SharedUI';
import { WHATSAPP_URL, EMAIL_URL } from '../lib/constants';

export default function Home() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);

  return (
    <>
      <section className="relative pt-40 pb-20 md:pt-52 md:pb-32 px-6 overflow-hidden">
        <motion.div style={{ y }} className="absolute inset-0 pointer-events-none flex justify-center items-center opacity-40">
          <div className="w-[800px] h-[800px] bg-gradient-to-tr from-zinc-100 to-white rounded-full blur-3xl absolute top-0 -left-64 translate-y-[-20%]"></div>
          <div className="w-[600px] h-[600px] bg-transparent border-[100px] border-zinc-50 rounded-full blur-2xl absolute top-64 right-[-100px]"></div>
        </motion.div>

        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center relative z-10">
          <div className="text-center md:text-left">
            <TypingEffect />
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter leading-tight mb-8">
              We fix <span className="text-gradient">broken</span> web presence.
            </h1>
            <p className="text-lg md:text-xl text-zinc-500 mb-10 max-w-lg mx-auto md:mx-0">
              Web404 is a South African web development agency. We build sleek, fast, and highly-converting websites that turn your visitors into customers.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <a 
                href={WHATSAPP_URL} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-center gap-2 bg-black text-white px-8 py-4 rounded-full font-semibold hover:shadow-[0_20px_40px_rgba(0,0,0,0.15)] transition-all hover:-translate-y-1 group"
              >
                <MessageCircle size={20} className="group-hover:scale-110 transition-transform" />
                Get a Free Quote on WhatsApp
              </a>
              <Link 
                to="/services"
                className="flex items-center justify-center gap-2 bg-white border border-zinc-200 text-zinc-800 px-8 py-4 rounded-full font-semibold hover:bg-zinc-50 hover:shadow-sm transition-all"
              >
                View Our Services
              </Link>
            </div>
          </div>

          <div className="hidden md:block h-[500px] relative rounded-3xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-zinc-100 bg-white">
            <Canvas>
              <PerspectiveCamera makeDefault position={[0, 0, 8]} />
              <ambientLight intensity={0.5} />
              <directionalLight position={[10, 10, 5]} intensity={1} />
              <pointLight position={[-10, -10, -5]} intensity={0.5} />
              <Environment preset="city" />
              <Suspense fallback={null}>
                <HeroShapes />
              </Suspense>
            </Canvas>
            
            <motion.div 
              animate={{ y: [-10, 10, -10] }} 
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute right-8 top-8 w-16 h-16 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl flex items-center justify-center border border-white/50"
            >
              <CodeIcon size={24} className="text-zinc-800" />
            </motion.div>
            <motion.div 
              animate={{ y: [15, -15, 15] }} 
              transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
              className="absolute left-8 bottom-8 w-24 h-12 bg-white/80 backdrop-blur-md rounded-xl shadow-xl flex items-center justify-center border border-white/50 font-mono text-xs font-bold text-black"
            >
              200 OK
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-[#FAFAFA]">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold tracking-tight mb-6">Why choose Web404?</h2>
            <p className="text-xl text-zinc-500 mb-10">We strip away the agency bloat and tech jargon to deliver fast, beautiful, and secure websites that actually grow your South African business.</p>
            <div className="space-y-6">
              {[
                { title: "Free Demo Websites", desc: "Try before you commit. We'll build a custom working prototype for your brand completely free." },
                { title: "Under 2 Weeks Delivery", desc: "We work fast. Your new website is usually launched in under 2 weeks." },
                { title: "South African Based", desc: "Local support. We understand the local market." },
                { title: "Results-Driven Focus", desc: "Every pixel is placed to convert visitors to leads." },
              ].map((item, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <div className="mt-1 bg-white p-1 rounded-full shadow-sm">
                    <CheckCircle2 className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">{item.title}</h4>
                    <p className="text-zinc-600">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative h-[600px] w-full flex items-center justify-center rounded-3xl overflow-hidden bg-gradient-to-br from-zinc-100 to-white shadow-inner border border-zinc-200">
             <div className="absolute inset-0">
               <Canvas>
                  <PerspectiveCamera makeDefault position={[0, 0, 8]} />
                  <ambientLight intensity={0.5} />
                  <directionalLight position={[10, 10, 5]} intensity={1} />
                  <pointLight position={[-10, -10, -5]} intensity={0.5} />
                  <Environment preset="city" />
                  <Suspense fallback={null}>
                    <Float speed={2} rotationIntensity={1.5} floatIntensity={2}>
                      <Icosahedron args={[2.5, 0]}>
                         <MeshDistortMaterial color="#ffffff" metalness={0.9} roughness={0} distort={0.4} speed={2} />
                      </Icosahedron>
                    </Float>
                  </Suspense>
               </Canvas>
             </div>
             <div className="relative z-10 grid grid-cols-2 gap-4 perspective-1000 pointer-events-none">
                <motion.div 
                  whileHover={{ scale: 1.05, z: 20 }}
                  style={{ transformStyle: "preserve-3d" }}
                  className="bg-white/80 backdrop-blur-md p-8 rounded-2xl shadow-xl w-48 h-48 flex flex-col items-center justify-center translate-y-8 border border-white/50"
                >
                  <Zap size={40} className="mb-4 text-black" />
                  <span className="font-bold text-center">Lightning Fast</span>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, z: 20 }}
                  style={{ transformStyle: "preserve-3d" }}
                  className="bg-black/90 backdrop-blur-md text-white p-8 rounded-2xl shadow-xl w-48 h-48 flex flex-col items-center justify-center -translate-y-8 border border-zinc-800"
                >
                  <Globe2 size={40} className="mb-4" />
                  <span className="font-bold text-center">SEO Ready</span>
                </motion.div>
             </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-white border-y border-zinc-100">
        <div className="max-w-5xl mx-auto">
           <div className="text-center mb-16">
            <h2 className="text-4xl font-bold tracking-tight mb-4">How it works</h2>
            <p className="text-xl text-zinc-500">Three simple steps to your new online presence.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 relative">
            <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-0.5 bg-zinc-100 -z-10"></div>
            
            {[
              { step: "01", title: "Chat", desc: "Message us on WhatsApp. Tell us about your business and goals." },
              { step: "02", title: "Free Custom Demo", desc: "We build a free working demo website for you to review before you commit." },
              { step: "03", title: "Launch in < 2 Weeks", desc: "Once approved, your site goes live, fully optimized and ready to convert." }
            ].map((s, i) => (
              <div key={i} className="text-center relative">
                <div className="w-24 h-24 mx-auto bg-white border border-zinc-200 rounded-full shadow-sm flex items-center justify-center text-2xl font-mono font-bold mb-6">
                  {s.step}
                </div>
                <h4 className="text-2xl font-bold mb-3">{s.title}</h4>
                <p className="text-zinc-500 px-4">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-[#FAFAFA] overflow-hidden">
         <div className="max-w-7xl mx-auto">
           <div className="text-center mb-16">
             <h2 className="text-4xl font-bold tracking-tight">Don't just take our word for it.</h2>
           </div>
           
           <div className="flex flex-wrap justify-center gap-8">
             {[
               { name: "John Smith", role: "Local Plumber", text: "Web404 rebuilt my dusty old site in a week. I've seen a 3x increase in WhatsApp leads since we went live. Incredible value." },
               { name: "Sarah Jenkins", role: "Boutique Owner", text: "Connor understood exactly what I wanted. Sleek, fast, and it works perfectly on mobile. Highly recommended!" }
             ].map((t, i) => (
               <motion.div 
                 key={i}
                 whileHover={{ y: -10 }}
                 className="bg-white border border-zinc-100 p-8 rounded-2xl w-full max-w-md shadow-sm"
               >
                 <div className="flex text-amber-400 mb-6">
                   {[...Array(5)].map((_, j) => <Star key={j} size={20} fill="currentColor" />)}
                 </div>
                 <p className="text-lg text-zinc-700 mb-8 italic">"{t.text}"</p>
                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-zinc-200 rounded-full flex items-center justify-center">
                     <UserCircle2 className="text-zinc-500" />
                   </div>
                   <div>
                     <h5 className="font-bold">{t.name}</h5>
                     <span className="text-sm text-zinc-500">{t.role}</span>
                   </div>
                 </div>
               </motion.div>
             ))}
           </div>
         </div>
      </section>

      <CTASection />
    </>
  );
}
